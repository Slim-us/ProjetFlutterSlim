import 'package:flutter/material.dart';

class RewardsCalculationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rewards Calculation'),
      ),
      body: Center( // Center the entire body
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically
            children: [
              Text('Rewards Calculation', style: TextStyle(fontSize: 24)),
              SizedBox(height: 20),
              Text('Total Rewards: \$150', style: TextStyle(fontSize: 18)),
              SizedBox(height: 10),
              Text('Breakdown of Rewards:', style: TextStyle(fontSize: 18)),
              SizedBox(height: 10),
              Text('Base: \$100', style: TextStyle(fontSize: 16)),
              Text('Bonus: \$50', style: TextStyle(fontSize: 16)),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {},
                child: Text('Claim Rewards'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
