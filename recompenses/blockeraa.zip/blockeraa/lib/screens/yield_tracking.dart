import 'package:flutter/material.dart';

class YieldTrackingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Yield Tracking'),
      ),
      body: Center( // Center the entire body
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically
            children: [
              Text('Yield Tracking', style: TextStyle(fontSize: 24)),
              SizedBox(height: 20),
              Text('Staked Amount: \$1000', style: TextStyle(fontSize: 18)),
              SizedBox(height: 10),
              Text('Current Yield: \$50', style: TextStyle(fontSize: 18)),
              SizedBox(height: 20),
              LinearProgressIndicator(
                value: 0.3, // Progress value
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {},
                child: Text('Withdraw'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
