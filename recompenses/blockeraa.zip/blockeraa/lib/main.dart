import 'package:flutter/material.dart';
import 'screens/staking_options.dart';
import 'screens/yield_tracking.dart';
import 'screens/rewards_calculation.dart';
import 'screens/notifications.dart';

void main() {
  runApp(StakingApp());
}

class StakingApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Staking & Rewards',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Staking & Rewards'),
      ),
      body: Center( // Center the entire body
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center the buttons vertically
            children: [
              // Add the logo
              Image.asset(
                'assets/blockera.png', // Path to your logo
                height: 100, // Adjust the height as needed
              ),
              SizedBox(height: 20), // Space between logo and buttons
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => StakingOptionsScreen()),
                  );
                },
                child: Text('Staking Options'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => YieldTrackingScreen()),
                  );
                },
                child: Text('Yield Tracking'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RewardsCalculationScreen()),
                  );
                },
                child: Text('Rewards Calculation'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => NotificationsScreen()),
                  );
                },
                child: Text('Notifications'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
